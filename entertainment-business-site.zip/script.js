document.addEventListener("DOMContentLoaded", function () {
    const eventList = document.getElementById("event-list");
    const events = [{ name: "Industry Night", date: "Feb 20, 2025" }, { name: "Panel Talk", date: "Mar 10, 2025" }];
    events.forEach(event => { let li = document.createElement("li"); li.textContent = `${event.name} - ${event.date}`; eventList.appendChild(li); });
});